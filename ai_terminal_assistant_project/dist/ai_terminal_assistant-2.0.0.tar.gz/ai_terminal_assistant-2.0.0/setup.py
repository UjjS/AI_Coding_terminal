from setuptools import setup

# This setup.py is minimal because most configuration is in pyproject.toml.
# It's useful for ensuring setuptools is used.
if __name__ == "__main__":
    setup()