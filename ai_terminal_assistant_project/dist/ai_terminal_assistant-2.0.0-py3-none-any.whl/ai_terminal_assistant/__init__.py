# This file makes 'ai_terminal_assistant' a Python package.

# You can optionally expose key components here for easier import if needed:
# from .main_gui import TerminalAssistant, run_assistant
# from .ai_utils import client, SYSTEM_PROMPT

__version__ = "2.0.0" # Package version